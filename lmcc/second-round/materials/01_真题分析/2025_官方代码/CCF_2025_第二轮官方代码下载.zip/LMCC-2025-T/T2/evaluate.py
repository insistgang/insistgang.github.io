# -*- coding: utf-8 -*-
"""
T2 小小古诗词助手（检索作答）- 评测主程序
本文件不可修改

环境要求：
    在运行本程序前，请确保已激活正确的 conda 环境：
    $ conda activate PyTorch-2.6.0
    
    必须使用 PyTorch-2.6.0 环境，否则可能缺少必要的依赖包或版本不匹配。
"""

import json
import re
import time
import argparse
import os
import warnings
from pathlib import Path
from typing import List, Dict, Tuple
from datetime import datetime

# 过滤 torch_npu 相关的警告
warnings.filterwarnings("ignore", category=UserWarning, module="torch_npu")

import torch_npu
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import transformers
import random

# 设置随机种子以确保结果可复现
SEED = 20251115
random.seed(SEED)
torch.manual_seed(SEED)

# 设置 transformers 日志级别，隐藏警告信息
transformers.logging.set_verbosity_error()

# 导入考生实现的函数
from submission import (
    build_system_prompt, 
    build_generation_parameters, 
    retrieve_relevant_poems,
    build_user_message
)


# ============================================================
# 工具函数
# ============================================================
def print_memory_info(model: AutoModelForCausalLM):
    """显示模型显存使用情况"""
    print("\n【显存使用情况】")
    try:
        # 获取模型所在的设备
        device = next(model.parameters()).device
        
        # 尝试使用 torch.cuda（如果可用）
        if torch.cuda.is_available() and device.type == 'cuda':
            allocated = torch.cuda.memory_allocated(device) / 1024**3  # GB
            reserved = torch.cuda.memory_reserved(device) / 1024**3  # GB
            max_allocated = torch.cuda.max_memory_allocated(device) / 1024**3  # GB
            print(f"  设备: {device}")
            print(f"  已分配显存: {allocated:.2f} GB")
            print(f"  已保留显存: {reserved:.2f} GB")
            print(f"  峰值显存: {max_allocated:.2f} GB")
        # 尝试使用 torch_npu（如果可用）
        elif hasattr(torch, 'npu') and hasattr(torch.npu, 'is_available') and torch.npu.is_available():
            try:
                allocated = torch.npu.memory_allocated(device) / 1024**3  # GB
                reserved = torch.npu.memory_reserved(device) / 1024**3  # GB
                max_allocated = torch.npu.max_memory_allocated(device) / 1024**3  # GB
                print(f"  设备: {device}")
                print(f"  已分配显存: {allocated:.2f} GB")
                print(f"  已保留显存: {reserved:.2f} GB")
                print(f"  峰值显存: {max_allocated:.2f} GB")
            except:
                # 如果 torch.npu.memory_allocated 不存在，使用通用方法
                raise
        else:
            # 通用方法：统计模型参数占用的显存
            total_params = sum(p.numel() for p in model.parameters())
            trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
            # 假设使用 float16，每个参数2字节
            model_size_gb = total_params * 2 / 1024**3
            print(f"  设备: {device}")
            print(f"  模型参数量: {total_params:,}")
            print(f"  可训练参数: {trainable_params:,}")
            print(f"  模型大小（估算）: {model_size_gb:.2f} GB (float16)")
    except Exception as e:
        # 如果所有方法都失败，至少显示设备信息
        try:
            device = next(model.parameters()).device
            print(f"  设备: {device}")
            print(f"  无法获取详细显存信息: {e}")
        except:
            print(f"  无法获取显存信息: {e}")


def load_jsonl(file_path: str) -> List[Dict]:
    """加载 JSONL 文件"""
    data = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                data.append(json.loads(line))
    return data


def extract_answer(text: str) -> str:
    """
    从模型输出中提取答案
    - 查找 [Answer]: X 格式
    - 如果有多个，取最后一个
    - 返回提取的选项（A/B/C/D）或空字符串
    """
    # 匹配所有 [Answer]: A/B/C/D，取最后一个
    matches = re.findall(r'\[Answer\]:\s*([A-D])', text, re.IGNORECASE)
    if matches:
        return matches[-1].upper()  # 返回最后一个匹配
    return ""


def remove_thinking_tags(text: str) -> str:
    """移除 <think>...</think> 标签及其内容"""
    return re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)


def save_evaluation_record(task_name: str, correct: int, total: int, score: int, total_time: float):
    """
    保存评测记录到用户目录的 .lmcc 文件夹
    """
    try:
        # 创建记录目录
        home_dir = Path.home()
        lmcc_dir = home_dir / ".lmcc"
        lmcc_dir.mkdir(exist_ok=True)
        
        # 记录文件路径
        record_file = lmcc_dir / "evaluation_records.jsonl"
        
        # 准备记录数据
        record = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "task": task_name,
            "correct": correct,
            "total": total,
            "score": score,
            "total_time": round(total_time, 2)
        }
        
        # 追加写入记录
        with open(record_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        
        print(f"\n✓ 评测记录已保存到: {record_file}")
    except Exception as e:
        print(f"\n⚠ 保存评测记录失败: {e}")


def format_problem(item: Dict) -> str:
    """
    将题目格式化为字符串
    新格式：题目和选项已经在problem字段中混合在一起
    """
    problem = item["problem"]
    return problem




def apply_chat_template(
    tokenizer: AutoTokenizer,
    system_prompt: str,
    user_message: str,
    enable_thinking: bool = False,
) -> str:
    """
    将问题转换为模型输入文本
    - 使用 tokenizer.apply_chat_template
    - 返回拼装好的文本字符串
    """
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=enable_thinking,
    )
    return rendered


def generate_single(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    rendered_text: str,
    generation_params: Dict,
) -> Tuple[torch.Tensor, int]:
    """
    单条推理（半精度、推理模式）
    - 输入：拼装好的文本字符串
    - 输出：(完整序列, 输入长度)
    """
    # 确保模型处于推理模式
    model.eval()
    
    # 1. tokenize 输入
    inputs = tokenizer(rendered_text, return_tensors="pt", padding=True).to(model.device)
    input_length = inputs["input_ids"].shape[1]
    
    # 2. 准备生成参数
    gen_kwargs = {
        "input_ids": inputs["input_ids"],
        "attention_mask": inputs.get("attention_mask"),
        "eos_token_id": tokenizer.eos_token_id,
        "pad_token_id": tokenizer.pad_token_id,
    }
    
    # 添加用户配置的参数
    gen_kwargs.update(generation_params)
    
    # 移除 enable_thinking（这个参数不是 generate 的参数）
    gen_kwargs.pop("enable_thinking", None)
    
    # 3. 生成输出（使用 no_grad 禁用梯度计算，推理模式）
    with torch.no_grad():
        outputs = model.generate(**gen_kwargs)
    
    return outputs, input_length


# ============================================================
# 评测函数
# ============================================================
def evaluate(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    system_prompt: str,
    test_data: List[Dict],
    knowledge_base: List[Dict],
    generation_params: Dict,
    mode: str,
) -> Tuple[int, int, float]:
    """
    评测函数（10题）
    返回：(正确数, 总题数, 总耗时)
    """
    print("\n" + "="*60)
    print("开始评测（10题）")
    print("="*60)
    
    # 显示评测开始前的显存信息
    print("\n【评测开始前显存状态】")
    print_memory_info(model)
    
    correct = 0
    total = len(test_data)
    total_time = 0.0
    
    enable_thinking = generation_params.get("enable_thinking", False)
    
    for idx, item in enumerate(test_data, 1):
        problem = format_problem(item)
        expected = item["answer"]
        
        # 步骤1：检索相关诗词
        retrieved_poems = retrieve_relevant_poems(problem, knowledge_base, top_k=3)
        
        # 步骤2：由考生函数组装用户消息
        user_message = build_user_message(problem, retrieved_poems)
        
        # 步骤3：拼装输入
        rendered_text = apply_chat_template(
            tokenizer, system_prompt, user_message, enable_thinking
        )
        
        # 推理
        start_time = time.time()
        output_ids, input_length = generate_single(
            model=model,
            tokenizer=tokenizer,
            rendered_text=rendered_text,
            generation_params=generation_params,
        )
        elapsed = time.time() - start_time
        total_time += elapsed
        
        # 只解码模型新生成的 token（不包括输入部分）
        generated_ids = output_ids[0, input_length:]
        generated_text = tokenizer.decode(generated_ids, skip_special_tokens=False)
        
        # 移除思考标签
        non_thinking_text = remove_thinking_tags(generated_text)
        
        # 提取答案
        predicted = extract_answer(non_thinking_text)
        
        # 统计答案标记数量（用于调试）
        answer_marks = re.findall(r'\[Answer\]:\s*([A-D])', non_thinking_text, re.IGNORECASE)
        answer_count = len(answer_marks)
        
        # 判断正确性
        is_correct = (predicted == expected)
        if is_correct:
            correct += 1
        
        # 输出
        if mode == "demo":
            print(f"\n【题目 {idx}/{total}】")
            print(f"题面：")
            print(item['problem'])
            print(f"\n检索到的诗词数量：{len(retrieved_poems)}")
            if retrieved_poems:
                print("检索结果：")
                for i, poem in enumerate(retrieved_poems, 1):
                    print(f"  {i}. 《{poem['title']}》 - {poem['author']}")
                    print(f"     诗句：")
                    for para in poem['paragraphs']:
                        print(f"       {para}")
            
            # 显示用户消息（完整）
            print(f"\n{'='*70}")
            print("【用户消息（传给模型的完整输入）】")
            print(f"{'='*70}")
            print(user_message)
            print(f"{'='*70}")
            
            # 显示模型原始输出（完整，不截断）
            print(f"\n{'='*70}")
            print("【模型原始输出（完整）】")
            print(f"{'='*70}")
            print(non_thinking_text)
            print(f"{'='*70}")
            
            print(f"\n正确答案：{expected}")
            print(f"提取的答案：{predicted if predicted else '(未提取到)'}")
            if answer_count > 1:
                print(f"⚠️  发现 {answer_count} 个答案标记: {answer_marks}（使用最后一个：{predicted}）")
            elif answer_count == 0:
                print(f"⚠️  未找到 [Answer]: 格式的答案")
            print(f"判定：{'✅ 正确' if is_correct else '❌ 错误'}")
            print(f"耗时：{elapsed:.3f}s")
        elif mode == "grading":
            status = "✅" if is_correct else "❌"
            print(f"题目 {idx}/{total}: {status}", flush=True)
    
    if mode == "grading":
        print()  # 换行
    
    # 显示评测结束后的显存信息
    print("\n【评测结束后显存状态】")
    print_memory_info(model)
    
    return correct, total, total_time


# ============================================================
# 主函数
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="T2 小小古诗词助手（检索作答）- 评测程序")
    parser.add_argument(
        "--mode",
        type=str,
        required=True,
        choices=["demo", "grading"],
        help="运行模式：demo（详细输出）或 grading（简洁输出）",
    )
    args = parser.parse_args()
    
    mode = args.mode
    
    print("="*60)
    print("T2 小小古诗词助手（检索作答）- 评测程序")
    print("="*60)
    print(f"运行模式：{mode}")
    
    # 加载知识库
    print("\n正在加载唐诗知识库...")
    data_dir = Path(__file__).parent / "data"
    with open(data_dir / "tangshi.json", "r", encoding="utf-8") as f:
        knowledge_base = json.load(f)
    print(f"知识库加载完成！共 {len(knowledge_base)} 首诗")
    
    # 加载模型
    print("\n正在加载模型...")
    model_path = os.environ.get("MODEL_NAME", "/home/ma-user/Qwen/Qwen/Qwen3-0.6B/")
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    # 加载模型（半精度）
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float16,  # 半精度
        device_map="auto",
        trust_remote_code=True,
    )
    # 设置为推理模式
    model.eval()
    # 禁用梯度计算以节省显存和加速推理
    for param in model.parameters():
        param.requires_grad = False
    print("模型加载完成！（半精度、推理模式）")
    
    # 显示显存信息
    print_memory_info(model)
    
    # 构建 system prompt
    system_prompt = build_system_prompt()
    
    # 检查 system_prompt token 数量
    system_prompt_tokens = tokenizer.encode(system_prompt, add_special_tokens=False)
    system_prompt_token_count = len(system_prompt_tokens)
    max_system_prompt_tokens = 1024 * 2  # 2048
    
    if mode == "demo":
        print("\n【System Prompt】")
        print(system_prompt)
        print(f"\nSystem Prompt Token 数量：{system_prompt_token_count}/{max_system_prompt_tokens}")
    
    # 验证 token 数量限制
    if system_prompt_token_count > max_system_prompt_tokens:
        print(f"\n❌ 错误：System Prompt 超过限制！")
        print(f"   当前 token 数：{system_prompt_token_count}")
        print(f"   限制：{max_system_prompt_tokens}")
        print(f"   超出：{system_prompt_token_count - max_system_prompt_tokens} tokens")
        return
    
    # 获取生成参数
    generation_params = build_generation_parameters()
    if mode == "demo":
        print("\n【Generation Parameters】")
        for key, value in generation_params.items():
            print(f"  {key}: {value}")
    
    # 加载测试数据
    test_data = load_jsonl(data_dir / "test_data.jsonl")
    
    # 评测
    correct, total, total_time = evaluate(
        model, tokenizer, system_prompt, test_data, knowledge_base, generation_params, mode
    )
    
    # 计算分数：每题5分，满分50分
    score = correct * 5
    
    # 输出总结
    print("\n" + "="*60)
    print("评测总结")
    print("="*60)
    print(f"正确题数：{correct}/{total}")
    print(f"总耗时：{total_time:.2f}s")
    print(f"得分：{score}/50")
    print("="*60)
    
    # 保存评测记录
    save_evaluation_record(
        task_name="T2-小小古诗词助手（检索作答）",
        correct=correct,
        total=total,
        score=score,
        total_time=total_time
    )


if __name__ == "__main__":
    main()
