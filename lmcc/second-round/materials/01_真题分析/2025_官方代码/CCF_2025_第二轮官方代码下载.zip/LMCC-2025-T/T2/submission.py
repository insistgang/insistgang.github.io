# -*- coding: utf-8 -*-
"""
仅此文件允许考生修改：
- 请在下列函数的函数体内完成实现。
- 不要改动函数名与参数签名。
"""

from typing import List, Dict


# ============================================================
# 检索函数（考生实现）
# ============================================================
def retrieve_relevant_poems(problem: str, knowledge_base: List[Dict], top_k: int = 3) -> List[Dict]:
    """
    考生实现：从知识库中检索与题目相关的诗词
    
    参数：
        problem: 题目文本，包含诗句和选项
        knowledge_base: 唐诗知识库，每个元素是一个字典，包含：
            - author: 作者
            - title: 诗名
            - paragraphs: 诗句列表
            - prologue: 解释（可能为空）
        top_k: 返回最相关的前 k 首诗
    
    返回：
        包含最相关的 top_k 首诗的列表
    
    提示：
        1. 可以提取题目中的关键诗句（去掉选项部分）
        2. 在知识库的 paragraphs 中搜索包含相关内容的诗
        3. 简单的字符串匹配即可，也可以使用更复杂的方法
        4. 建议从题目中提取连续的诗句片段进行匹配
        5. 进阶：使用 n-gram 可以提高匹配的灵活性和召回率
    """
    # ======== 考生实现区域（可修改） ========
    
    retrieved = []
    # TODO: 实现检索逻辑

    return retrieved[:top_k]
    
    # ======== 考生实现区域（可修改） ========


# ============================================================
# Prompt 定义（考生实现）
# ============================================================
def build_user_message(problem: str, retrieved_poems: List[Dict]) -> str:
    """
    考生实现：组装用户消息（包含检索内容和题目）
    
    参数：
        problem: 题目文本
        retrieved_poems: 检索到的诗词列表，每个元素包含：
            - author: 作者
            - title: 诗名
            - paragraphs: 诗句列表
            - prologue: 解释（可能为空）
    
    返回：
        完整的用户消息字符串
    
    提示：
        你可以决定：
        1. 是否使用检索到的诗词
        2. 如何格式化检索内容（简洁版或详细版）
        3. 检索内容放在题目前面还是后面
        4. 如何组织整体结构
        
    示例格式1（详细版）：
        【参考知识】
        【诗1】
        作者：李白
        诗名：静夜思
        诗句：
          床前明月光，疑是地上霜。
          举头望明月，低头思故乡。
        
        【题目】
        床前明月光,_____.
        选项：A. 疑是地上霜 ...
    
    示例格式2（简洁版）：
        参考诗句：
        1. 床前明月光，疑是地上霜。举头望明月，低头思故乡。（静夜思 - 李白）
        
        题目：床前明月光,_____.
        选项：A. 疑是地上霜 ...
    """
    # ======== 考生实现区域（可修改） ========
    
    # TODO: 实现用户消息组装逻辑
    
    # 示例代码框架：
    if not retrieved_poems:
        return problem
    else:
        return f"【参考知识】\n{retrieved_poems}\n【题目】\n{problem}"
    
    # ======== 考生实现区域（可修改） ========


def build_system_prompt() -> str:
    """
    考生实现：定义 system prompt（RAG 版本）
    
    要求：
    1. 引导模型理解古诗词选择题的任务
    2. 说明会提供检索到的相关诗词作为参考知识
    3. 要求模型基于提供的参考知识来回答问题
    4. 要求模型严格按照 [Answer]: X 的格式输出答案（X 为 A/B/C/D）
    5. 强调不要输出其他解释或说明
    
    返回：system prompt 字符串
    """
    # ======== 考生实现区域（可修改） ========
    
    return """你是古诗词助手。请根据参考知识回答问题。

【你的 prompt 写在这里】

"""
    
    # ======== 考生实现区域（可修改） ========


def build_generation_parameters() -> dict:
    """
    考生实现：定义生成参数
    
    可配置的参数：
    - max_new_tokens: 最大生成 token 数（默认 512）
    - do_sample: 是否使用采样（默认 False，使用贪心解码）
    - temperature: 温度参数（仅当 do_sample=True 时有效）
    - top_p: nucleus sampling 参数（仅当 do_sample=True 时有效）
    - enable_thinking: 是否开启 Thinking 模式（默认 False）
    
    返回：生成参数字典
    """
    # ======== 考生实现区域（可修改） ========
    
    return {
        "max_new_tokens": 128,       # 根据需求选择合适的token数
        "do_sample": False,          # 使用贪心解码,保证输出稳定
        "enable_thinking": False,    # 不开启思考模式,直接输出答案
    }
    
    # ======== 考生实现区域（可修改） ========


